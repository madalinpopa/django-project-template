"use strict";
/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkdjango_project_template"] = self["webpackChunkdjango_project_template"] || []).push([["index"],{

/***/ "./project_name/assets/index.js":
/*!**************************************!*\
  !*** ./project_name/assets/index.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _images_favicon_ico__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./images/favicon.ico */ \"./project_name/assets/images/favicon.ico\");\n/* harmony import */ var _css_main_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./css/main.css */ \"./project_name/assets/css/main.css\");\n/* harmony import */ var alpinejs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! alpinejs */ \"./node_modules/alpinejs/dist/module.esm.js\");\n/**\n * Images\n */\n\n/**\n * Style\n */\n\n\n/**\n * Third party libraries\n */\n\n\n/**\n * Htmx setup\n */\nwindow.htmx = __webpack_require__(/*! htmx.org */ \"./node_modules/htmx.org/dist/htmx.min.js\");\n\n/**\n * Alpine setup\n */\nalpinejs__WEBPACK_IMPORTED_MODULE_2__[\"default\"].start();\nconsole.log(\"Hello World\");\n\n//# sourceURL=webpack://django-project-template/./project_name/assets/index.js?");

/***/ }),

/***/ "./project_name/assets/css/main.css":
/*!******************************************!*\
  !*** ./project_name/assets/css/main.css ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n// extracted by mini-css-extract-plugin\n\n\n//# sourceURL=webpack://django-project-template/./project_name/assets/css/main.css?");

/***/ }),

/***/ "./project_name/assets/images/favicon.ico":
/*!************************************************!*\
  !*** ./project_name/assets/images/favicon.ico ***!
  \************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

eval("module.exports = __webpack_require__.p + \"./images/favicon.ico\";\n\n//# sourceURL=webpack://django-project-template/./project_name/assets/images/favicon.ico?");

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["htmx","alpine"], () => (__webpack_exec__("./project_name/assets/index.js")));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);